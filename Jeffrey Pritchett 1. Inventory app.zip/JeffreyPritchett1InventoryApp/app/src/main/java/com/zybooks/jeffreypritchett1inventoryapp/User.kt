package com.zybooks.jeffreypritchett1inventoryapp

data class User(val username: String, val password: String)

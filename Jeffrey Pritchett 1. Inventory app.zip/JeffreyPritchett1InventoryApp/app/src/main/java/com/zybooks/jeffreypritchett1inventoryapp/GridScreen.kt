package com.zybooks.jeffreypritchett1inventoryapp

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.ui.Alignment

@Composable
fun GridScreen(dbHelper: DatabaseHelper) {
    val data = remember { dbHelper.getAllUsers() }

    LazyVerticalGrid(
        columns = GridCells.Fixed(2), // Set number of columns
        contentPadding = PaddingValues(8.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(data) { user ->
            GridItem(user)
        }
    }
}

@Composable
fun GridItem(user: User) {
    Column(
        modifier = Modifier
            .padding(8.dp)
            .fillMaxWidth()
            .border(1.dp, Color.Gray, RoundedCornerShape(8.dp))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Username: ${user.username}", style = MaterialTheme.typography.bodyLarge)
        Text(text = "Password: ${user.password}", style = MaterialTheme.typography.bodyLarge)
    }
}

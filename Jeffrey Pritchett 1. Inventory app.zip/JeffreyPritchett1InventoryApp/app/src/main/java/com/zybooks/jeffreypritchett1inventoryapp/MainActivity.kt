package com.zybooks.jeffreypritchett1inventoryapp

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.ui.Modifier
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.telephony.SmsManager
import androidx.compose.foundation.layout.padding
import com.zybooks.jeffreypritchett1inventoryapp.ui.theme.JeffreyPritchett1InventoryAppTheme

class MainActivity : ComponentActivity() {
    private val smsPermissionCode = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        checkSmsPermission()

        setContent {
            JeffreyPritchett1InventoryAppTheme {
                // Managing the screen state with a mutable state
                var currentScreen by remember { mutableStateOf<Screen>(Screen.Login) }

                Scaffold(
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    when (currentScreen) {
                        is Screen.Login -> LoginScreen(
                            modifier = Modifier.padding(innerPadding),
                            onLoginClick = { username, password ->
                                handleLogin(username, password)
                            },
                            onSignupClick = {
                                currentScreen = Screen.Signup // Navigate to SignupScreen
                            }
                        )
                        is Screen.Signup -> SignupScreen(
                            modifier = Modifier.padding(innerPadding),
                            onSignupComplete = { username, password ->
                                handleSignup(username, password)
                                currentScreen = Screen.Login // Navigate back to LoginScreen
                            },
                            onBackClick = {
                                currentScreen = Screen.Login // Navigate back to LoginScreen
                            }
                        )
                    }
                }
            }
        }
    }

    private fun checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.SEND_SMS), smsPermissionCode)
        }
    }

    private fun handleLogin(username: String, password: String) {
        val db = DatabaseHelper(this)
        if (db.checkUser(username, password)) {
            Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show()
            // Trigger SMS alert on successful login
            triggerSmsAlert("your_phone_number", "Login Successful for $username")
            // Navigate to grid screen (this could be another state or screen)
            setContent { GridScreen(dbHelper = db) }
        } else {
            Toast.makeText(this, "Invalid Credentials", Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleSignup(username: String, password: String) {
        val db = DatabaseHelper(this)
        if (db.addUser(username, password)) {
            Toast.makeText(this, "Signup Successful", Toast.LENGTH_SHORT).show()
            // Trigger SMS alert on successful signup
            triggerSmsAlert("your_phone_number", "Signup Successful for $username")
        } else {
            Toast.makeText(this, "Signup Failed", Toast.LENGTH_SHORT).show()
        }
    }

    private fun triggerSmsAlert(phoneNumber: String, message: String) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            sendSms(phoneNumber, message)
        } else {
            Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    private fun sendSms(phoneNumber: String, message: String) {
        val smsManager = SmsManager.getDefault()
        smsManager.sendTextMessage(phoneNumber, null, message, null, null)
    }
}

sealed class Screen {
    object Login : Screen()
    object Signup : Screen()
}

